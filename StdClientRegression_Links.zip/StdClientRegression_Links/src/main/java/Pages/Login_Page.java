package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_Page  {

	public WebDriver driver;

	@FindBy(xpath = "//input[@id='MainContent_txtUserName']") public WebElement userName;
	@FindBy(xpath = "//input[@id='MainContent_txtPassword']") public WebElement password;
	@FindBy(xpath = "//input[@id='MainContent_btnLogin']") public WebElement login;

	public Login_Page(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver loginStep(String userNameStr, String passwordStr) {

		this.userName.sendKeys(userNameStr);
		this.password.sendKeys(passwordStr);
		this.login.click();
		
		return driver;
	}
}
