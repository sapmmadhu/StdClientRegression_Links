package dataProviders;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class ConfigFileReader {	
	private Properties properties;
	private final String propertyFilePath= "src//test//resources//configs//Configuration.properties";

	public ConfigFileReader(){
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try { properties.load(reader); }
			catch (IOException e) { e.printStackTrace(); }
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Properties file not found at path : " + propertyFilePath);
		}finally {
			try { if(reader != null) reader.close(); }
			catch (IOException ignore) {}
		}
	}
	

	public String getExcelSheetFilePath(){
		String excelFilePath = properties.getProperty("excelFilePath");
		if(excelFilePath!= null) return excelFilePath;
		else throw new RuntimeException("excel File Path not specified in the Configuration.properties file for the Key:driverPath");		
	}
	
	public String getExcelSheetName(){
		String excelSheetName = properties.getProperty("sheetName");
		if(excelSheetName!= null) return excelSheetName;
		else throw new RuntimeException("excel Sheet Name not specified in the Configuration.properties file for the Key:driverPath");		
	}
	
	public String getDriverPath(){
		String driverPath = properties.getProperty("driverPath");
		if(driverPath!= null) return driverPath;
		else throw new RuntimeException("Driver Path not specified in the Configuration.properties file for the Key:driverPath");		
	}
	
	public long getImplicitlyWait() {		
		String implicitlyWait = properties.getProperty("implicitlyWait");
		if(implicitlyWait != null) {
			try{
				return Long.parseLong(implicitlyWait);
			}catch(NumberFormatException e) {
				throw new RuntimeException("Not able to parse value : " + implicitlyWait + " in to Long");
			}
		}
		return 30;		
	}
	
	public String getAppUrl() {
		String url = properties.getProperty("url");
		if(url != null) return url;
		else throw new RuntimeException("Application Url not specified in the Configuration.properties file for the Key:url");
	}
	
	public String getAppUsername() {
		String url = properties.getProperty("username");
		if(url != null) return url;
		else throw new RuntimeException("Application name not specified in the Configuration.properties file for the Key:url");
	}
	
	public String getAppPassword() {
		String url = properties.getProperty("password");
		if(url != null) return url;
		else throw new RuntimeException("Application password not specified in the Configuration.properties file for the Key:url");
	}
	
	public String getBroswerName() {
		String browser = properties.getProperty("browser");
		return browser;
	}
	
	
	public Boolean getBrowserWindowSize() {
		String windowSize = properties.getProperty("windowMaximize");
		if(windowSize != null) return Boolean.valueOf(windowSize);
		return true;
	}
	
	public String getTestDataResourcePath(){
		String testDataResourcePath = properties.getProperty("testDataResourcePath");
		if(testDataResourcePath!= null) return testDataResourcePath;
		else throw new RuntimeException("Test Data Resource Path not specified in the Configuration.properties file for the Key:testDataResourcePath");		
	}
	
	public String getReportConfigPath(){
		String reportConfigPath = properties.getProperty("reportConfigPath");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}

}
