package drivers;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotCapture {
	public WebDriver driver;
	
	public ScreenshotCapture(WebDriver driver) {
		this.driver=driver;
	}

	public String getScreenShot() throws IOException {
		TakesScreenshot screenShot = ((TakesScreenshot) driver);
		File srcF = screenShot.getScreenshotAs(OutputType.FILE);
		File desF = new File("src//test//resources//configs//Temp.png");
		if (!desF.exists()) {
			srcF.createNewFile();
		}
		FileUtils.copyFile(srcF, desF);
		return desF.getAbsoluteFile().toString();
	}
}
