package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Tests.Applications.Applications;
import Tests.Applications.Result;
import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;
import drivers.SetupDriver;
import pages.Login_Page;

public class LinksValidations {

	public WebDriver driver;

	public SetupDriver setupDriver;
	public Login_Page lp;
	public Applications applications;
	public int DataSet = -1;
	public Result result = new Result();

	public static ConfigFileReader reader = new ConfigFileReader();
	public DataProvider_IN_OUT dp = new DataProvider_IN_OUT();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	static String sheetName = reader.getExcelSheetName();

	@BeforeSuite
	public void applicationsPage() {
		setupDriver = new SetupDriver(driver);
		driver = setupDriver.getDriver(reader.getBroswerName());
		driver.get(reader.getAppUrl());

		lp = new Login_Page(driver);
		driver = lp.loginStep(reader.getAppUsername(), reader.getAppPassword());
		applications = new Applications(driver);
	}

	@Test(dataProvider = "ReadVariant", dataProviderClass = DataProvider_IN_OUT.class)
	public void Links(String SlNo, String LinkName, String WorkingStatus, String ErrorMessage) throws Exception {

		DataSet++;

		String resultValue = applications.getApplication(LinkName);
		if (resultValue != "Yes")			

		{
			dp.WriteVariant(SheetFilePath, sheetName, "No", "WorkingStatus", DataSet + 1);
			dp.WriteVariant(SheetFilePath, sheetName, resultValue, "ErrorMessage", DataSet + 1);
		}

		else {
			dp.WriteVariant(SheetFilePath, sheetName, resultValue, "WorkingStatus", DataSet + 1);
		}
	}

	@AfterSuite
	public void tearDown() {
		// driver.close();
		driver.quit();
	}
}
