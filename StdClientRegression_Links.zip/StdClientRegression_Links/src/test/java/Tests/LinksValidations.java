package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Drivers.SetupDriver;
import Pages.Login_Page;
import Tests.Applications.Applications;

public class LinksValidations {

	public WebDriver driver;

	public SetupDriver setupDriver;
	public Login_Page lp;
	public Applications applications;

	@Test
	public void linksValidations() {

		setupDriver= new SetupDriver(driver);
		driver = setupDriver.getDriver("CHROME");
		driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");

		lp = new Login_Page(driver);
		lp.loginStep("C044925", "dddtesting");

		applications = new Applications(driver);
		
		// Below items are User Applications
		applications.getApplication("AHCCCS UTILITIES");
		applications.getApplication("CAPITATION INTRANET APPLICATION");
		applications.getApplication("CLIENT APPLICATION");
		applications.getApplication("CLIENT BILLING INTRANET");
		applications.getApplication("CONTRACT ADMINISTRATION SYSTEM");
		applications.getApplication("DIRECT SERVICE TRACKING");
		applications.getApplication("ENCOUNTER SYSTEM INTRANET");
		applications.getApplication("ISSUE TRACKING SYSTEM");
		applications.getApplication("OLCR TRACKING APPLICATION");
		applications.getApplication("PAYMENTS INTRANET");
		applications.getApplication("PERSONNEL TRACKING SYSTEM INTRANET");
		applications.getApplication("PROFESSIONAL BILLING SYSTEM INTRANET");
		applications.getApplication("PROGRAM MONITORING APPLICATION");
		applications.getApplication("PROGRAM STAFFING");
		applications.getApplication("QM INCIDENT REPORTING");
		applications.getApplication("QM RESOLUTION SYSTEM");
		applications.getApplication("REPORT MENU APPLICATION");
		
		// Below items are Global Applications
		applications.getApplication("CLIENT SEARCH");
		applications.getApplication("VENDOR SEARCH");
		applications.getApplication("WORKER SEARCH");		
	}
}

// DBA login credentials to validate regression suite links