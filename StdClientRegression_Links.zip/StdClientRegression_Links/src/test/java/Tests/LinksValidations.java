package Tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Drivers.SetupDriver;
import Pages.Login_Page;
import Tests.Applications.Applications;

public class LinksValidations {

	public WebDriver driver;

	public SetupDriver setupDriver;
	public Login_Page lp;
	public Applications applications;

	@Test
	public void linksValidations() {

		setupDriver= new SetupDriver(driver);
		driver = setupDriver.getDriver("CHROME");
		driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");

		lp = new Login_Page(driver);
		lp.loginStep("C044925", "dddtesting");

		applications = new Applications(driver);
		
		// Below items are User Applications
		applications.getApplication("AHCCCS UTILITIES");
		applications.getApplication("CAPITATION INTRANET APPLICATION");
		applications.getApplication("CLIENT APPLICATION");
		applications.getApplication("CLIENT BILLING INTRANET");
		applications.getApplication("CONTRACT ADMINISTRATION SYSTEM");
		applications.getApplication("DIRECT SERVICE TRACKING");
		applications.getApplication("ENCOUNTER SYSTEM INTRANET");
		applications.getApplication("ISSUE TRACKING SYSTEM");
		applications.getApplication("OLCR TRACKING APPLICATION");
		applications.getApplication("PAYMENTS INTRANET");
		applications.getApplication("PERSONNEL TRACKING SYSTEM INTRANET");
		applications.getApplication("PROFESSIONAL BILLING SYSTEM INTRANET");
		applications.getApplication("PROGRAM MONITORING APPLICATION");
		applications.getApplication("PROGRAM STAFFING");
		applications.getApplication("QM INCIDENT REPORTING");
		applications.getApplication("QM RESOLUTION SYSTEM");
		applications.getApplication("REPORT MENU APPLICATION");
		
		// Below items are Global Applications
		applications.getApplication("CLIENT SEARCH");
		applications.getApplication("VENDOR SEARCH");
		applications.getApplication("WORKER SEARCH");		
		
		
		// Print link messages
		WebElement msg=driver.findElement(By.xpath("// div[@id='MainContent_divCurrentApps']//a[contains(text(),'AHCCCS UTILITIES')]"));
		String text=msg.getText();
		
		
		/*
		 * List<WebElement> listofRows =
		 * driver.findElements(By.xpath("//*[@id=\"Table11\"]/tbody/tr")); for
		 * (WebElement list : listofRows) { String text = list.getText();
		 * System.out.println(text);
		 */
			
		if (msg.isEnabled() && text.contains("AHCCCS UTILITIES"))
		{ 
		    System.out.println("Ahcccs Utilities Application for Intranet.");
		    System.out.println("Capitation Application Front-End");
		    System.out.println("This application is the intranet version of Individual Service Plan and is intended for internal employees only.");
		    System.out.println("Client Billing Intranet Application");
		    System.out.println("Allows management and viewing of Contracts ");
		    System.out.println("Direct Service Tracking");
		    System.out.println("This application is the intranet version of the Payments system for internal employees only");
		    System.out.println("Issue Tracking System");
		    System.out.println("OLCR Vendor Certification Tracking System");
		    System.out.println("This application is the intranet version of the Payments system for internal employees only");
		    System.out.println("Personnel Tracking System Front-End");
		    System.out.println("This application is the intranet version of the PBS system for internal employees only");
		    System.out.println("Program Monitoring Application.");
		    System.out.println("Program Staffing");
		    System.out.println("Quality Management Incident Reporting");
		    System.out.println("Quality Management Consumer Resolution");
		    System.out.println("Report Menu Application");
		    
		}else{
		    System.out.println("Actual content from the webpage");
		}
	}
}

// After validations on the links, click operations are to be performed with print message in Excel