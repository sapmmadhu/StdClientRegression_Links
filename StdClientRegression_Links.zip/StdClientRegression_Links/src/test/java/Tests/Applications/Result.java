package Tests.Applications;

public class Result {

	public String returnValues(String  value) {
		String result= null;
		if(value.contains("Server Error in '/Organization/DDD/FocusDD' Application.")) {
			result="NO";
		}

		else {
			
			result="Yes";
			
		}
		return result;

	}
}
