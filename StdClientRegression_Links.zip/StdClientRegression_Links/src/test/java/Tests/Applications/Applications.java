package Tests.Applications;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import drivers.WindowHandler;

public class Applications {

	public WebDriver driver;
	public WindowHandler handler;
	public WindowHandler handler1;

	public Result result = new Result();

	public Applications(WebDriver driver) {
		this.driver = driver;
	}

	public String getApplication(String application) throws InterruptedException {
		driver.findElement(By.xpath("//div[@id='MainContent_divCurrentApps']//a[contains(text(),'" + application + "')]")).click();
		Thread.sleep(7000);
		String winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		String resultValue = null;
		if (driver.getPageSource().contains("Server Error in '/Organization/DDD/FocusDD' Application.")) {
			String headerValue = driver.findElement(By.tagName("h1")).getText();
			resultValue =headerValue;
		} else 
		{
			resultValue = "Yes";
		}
		driver.close();
		Thread.sleep(5000);
		driver.switchTo().window(winHandleBefore);
		
		
		return resultValue;
	}

}
