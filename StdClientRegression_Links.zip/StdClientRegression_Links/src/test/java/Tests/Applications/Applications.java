package Tests.Applications;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import dataProviders.ConfigFileReader;
import dataProviders.DataProvider_IN_OUT;
import drivers.ScreenshotCapture;
import drivers.WebDriverWaitt;
import drivers.WindowHandler;

public class Applications {

	public WebDriver driver;
	public WindowHandler handler;
	public WindowHandler handler1;
	public static ConfigFileReader reader = new ConfigFileReader();
	public DataProvider_IN_OUT dp = new DataProvider_IN_OUT();
	static String SheetFilePath = reader.getExcelSheetFilePath();
	static String sheetName = reader.getExcelSheetName();
	public WebDriverWaitt wd = new WebDriverWaitt();

	public Applications(WebDriver driver) {
		this.driver = driver;
	}

	public String getApplication(String SINo,String application) throws InterruptedException, IOException {
		WebElement element = driver.findElement(By.xpath("//a[contains(text(),'" + application + "')]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", element);
		driver.findElement(By.xpath("//a[contains(text(),'" + application + "')]")).click();
		Thread.sleep(7000);
		String winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles())

		{
			driver.switchTo().window(winHandle);
		}

		wd.waitForLoad(driver);

		String resultValue = null;
		if (driver.getPageSource().contains("Server Error in '/Organization/DDD/FocusDD' Application.")) {
			String headerValue = driver.findElement(By.tagName("h1")).getText();
			ScreenshotCapture scrnShot = new ScreenshotCapture(driver);
			String imageFile = scrnShot.getScreenShot();
			dp.SheetImage(imageFile, 0, 4, "SlNo"+SINo+"Image", reader.getExcelSheetFilePath());
			dp.writeExcel(reader.getExcelSheetFilePath(), "SlNo"+SINo+"Image", application, 0, 0);
			resultValue = headerValue;

		} else {
			resultValue = "Yes";
		}

		driver.close();
		Thread.sleep(5000);

		driver.switchTo().window(winHandleBefore);
		return resultValue;
	}

}
