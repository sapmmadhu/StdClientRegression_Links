package Tests.Applications;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import drivers.WebDriverWaitt;
import drivers.WindowHandler;

public class Applications {

	public WebDriver driver;
	public WindowHandler handler;
	public WindowHandler handler1;

	public Result result = new Result();
	public WebDriverWaitt wd = new WebDriverWaitt();

	public Applications(WebDriver driver) {
		this.driver = driver;
	}

	
	public String getApplication(String application) throws InterruptedException {
		WebElement element = driver.findElement(By.xpath("//a[contains(text(),'" + application + "')]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", element);
		driver.findElement(By.xpath("//a[contains(text(),'" + application + "')]")).click();
		Thread.sleep(7000);
		String winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles()) 
		
		{
			driver.switchTo().window(winHandle);
			
		}

		wd.waitForLoad(driver);

		String resultValue = null;
		if (driver.getPageSource().contains("Server Error in '/Organization/DDD/FocusDD' Application.")) {
			String headerValue = driver.findElement(By.tagName("h1")).getText();
			resultValue = headerValue;
		} else {
			resultValue = "Yes";
		}

		driver.close();
		Thread.sleep(5000);
		
		
		/*
		 * // To take the screenshot from error page 
		 * File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 * FileUtils.copyFile(screenshotFile, new File("D:\\SoftwareTestingMaterial.png")); 
		 * driver.close();
		 */
		
		
		driver.switchTo().window(winHandleBefore);

		return resultValue;
	}

}
