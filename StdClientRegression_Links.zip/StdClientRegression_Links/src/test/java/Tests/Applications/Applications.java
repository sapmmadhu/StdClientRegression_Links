package Tests.Applications;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Applications {

	public WebDriver driver;

	public Applications(WebDriver driver) {
		this.driver = driver;
	}
	
	
	
	// User Applications links
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'AHCCCS UTILITIES')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CAPITATION INTRANET APPLICATION')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT APPLICATION')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT BILLING INTRANET')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CONTRACT ADMINISTRATION SYSTEM')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'DIRECT SERVICE TRACKING')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'ENCOUNTER SYSTEM INTRANET')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'ISSUE TRACKING SYSTEM')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'OLCR TRACKING APPLICATION')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PAYMENTS INTRANET')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PERSONNEL TRACKING SYSTEM INTRANET')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROFESSIONAL BILLING SYSTEM INTRANET')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROGRAM MONITORING APPLICATION')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROGRAM STAFFING')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'QM INCIDENT REPORTING')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'QM RESOLUTION SYSTEM')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'REPORT MENU APPLICATION')]
	
	
	
	// Global Applications links
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT SEARCH')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'VENDOR SEARCH')]
	// div[@id='MainContent_divCurrentApps']//a[contains(text(),'WORKER SEARCH')]
	
	public WebDriver getApplication(String application) {
		driver.findElement(
				By.xpath("//div[@id='MainContent_divCurrentApps']//a[contains(text(),'"+application+"')]"))
				.click();
		return driver;
	}
}
