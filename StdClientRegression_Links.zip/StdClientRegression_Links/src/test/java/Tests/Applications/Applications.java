package Tests.Applications;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.google.common.collect.Table.Cell;

public class Applications {

	public WebDriver driver;

	public Applications(WebDriver driver) {
		this.driver = driver;
	}	
		
	// User Applications links after DBA login
	
	public void Links() {
			
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'AHCCCS UTILITIES')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CAPITATION INTRANET APPLICATION')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT APPLICATION')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT BILLING INTRANET')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CONTRACT ADMINISTRATION SYSTEM')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'DIRECT SERVICE TRACKING')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'ENCOUNTER SYSTEM INTRANET')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'ISSUE TRACKING SYSTEM')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'OLCR TRACKING APPLICATION')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PAYMENTS INTRANET')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PERSONNEL TRACKING SYSTEM INTRANET')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROFESSIONAL BILLING SYSTEM INTRANET')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROGRAM MONITORING APPLICATION')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'PROGRAM STAFFING')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'QM INCIDENT REPORTING')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'QM RESOLUTION SYSTEM')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'REPORT MENU APPLICATION')]
		
		
		// Global Applications links after DBA login
		
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'CLIENT SEARCH')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'VENDOR SEARCH')]
		// div[@id='MainContent_divCurrentApps']//a[contains(text(),'WORKER SEARCH')]
		
		
		// Main Menu
		// DDD Suggestions
		// DDD policy
		
	}	
	
	public WebDriver getApplication(String application) {
		driver.findElement(By.xpath("//div[@id='MainContent_divCurrentApps']//a[contains(text(),'"+application+"')]"))
				.click();
		return driver;
	}
	
	
	
	
	
	
	
	/*
	 * //Get text from webpage by declaring String variable, 
	 * String strText =driver.findElement(http://By.Id(�locator_value�)).getText();
	 * 
	 * //Create an object of Excel class it may be XSSF or HSSF.
	 * 
	 * //file location File path=new File(System.getProperty("user.dir")+"/RPF.xls");
	 * 
	 * FileInputStream fis=new FileInputStream(path); 
	 * HSSFWorkbook workbook = new HSSFWorkbook(fis); HSSFSheet sheet=workbook.getSheetAt(0); 
	 * 
	 * //create object of excel row and column 
	 * Row row =sheet.createRow(0); 
	 * //you can create any row with the for loop 
	 * Cell cell= sheet.getRow(1).createCell(0); 
	 * //create first column 
	 * cell.setCellValue(strText); fis.close();
	 * 
	 * //Create object of output file 
	 * 
	 * FileOutputStream outputStream = new FileOutputStream(path); 
	 * workbook.write(outputStream); 
	 * outputStream.close();
	 */
				
				
				
}
